create
    definer = renzo@`%` procedure productos_por_rango(IN precio_min int, IN precio_max int)
begin
    select * from productos p where Precio between precio_min and precio_max order by Precio;
end;

