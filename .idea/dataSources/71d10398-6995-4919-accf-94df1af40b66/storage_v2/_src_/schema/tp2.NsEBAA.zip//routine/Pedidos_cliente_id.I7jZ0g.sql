create
    definer = renzo@`%` procedure Pedidos_cliente_id(IN id_cliente int)
begin
    declare cliente_existe int;

    select count(*) into cliente_existe
    from clientes
    where id = id_cliente;

    if cliente_existe = 0 then
        signal sqlstate '45000'
            set message_text = 'Error: El cliente especificado no existe.';
    else
        select * from pedidos p where ClienteID = id_cliente;
    end if;
end;

