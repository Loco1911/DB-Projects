create definer = renzo@`%` view cliente_mas_gasto as
select `c`.`Nombre` AS `nombre`, `c`.`Apellido` AS `apellido`, sum(`p`.`MontoTotal`) AS `Gastos_Totales`
from (`tp2`.`clientes` `c` join `tp2`.`pedidos` `p` on ((`p`.`ClienteID` = `c`.`ID`)))
group by `c`.`ID`
order by `Gastos_Totales` desc
limit 1;

