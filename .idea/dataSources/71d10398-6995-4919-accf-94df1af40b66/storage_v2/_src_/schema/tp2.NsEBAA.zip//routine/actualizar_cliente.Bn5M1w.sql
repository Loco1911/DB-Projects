create
    definer = renzo@`%` procedure actualizar_cliente(IN id_cliente int, IN nombre_cliente varchar(100),
                                                     IN apellido_cliente varchar(100), IN email_cliente varchar(100),
                                                     IN tel varchar(20), IN fecha_reg date)
begin

    declare
        cliente_existe int;

    select count(*) into cliente_existe
    from clientes
    where id = id_cliente;

    if cliente_existe = 0 then
        signal sqlstate '45000'
            set message_text = 'Error: El cliente especificado no existe.';
    else
        update clientes set Nombre = coalesce(nombre_cliente, Nombre) , Apellido = coalesce(apellido_cliente, Apellido), Email = coalesce(email_cliente, Email), Telefono = coalesce(tel, Telefono), FechaRegistro = coalesce(fecha_reg, FechaRegistro) where ID= id_cliente;
    end if;

end;

