create
    definer = renzo@`%` procedure pedidos_por_fechas(IN fecha_inicio date, IN fecha_fin date)
begin
    select * from pedidos where FechaPedido between fecha_inicio and fecha_fin order by FechaPedido;
end;

