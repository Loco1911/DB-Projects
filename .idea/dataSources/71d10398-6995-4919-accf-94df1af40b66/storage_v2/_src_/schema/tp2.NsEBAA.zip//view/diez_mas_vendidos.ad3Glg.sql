create definer = renzo@`%` view diez_mas_vendidos as
select `p`.`ID`              AS `ID`,
       `p`.`NombreProducto`  AS `Nombre_Producto`,
       sum(`d`.`Cantidad`)   AS `Cantidad_Vendida`,
       `c`.`NombreCategoria` AS `NombreCategoria`
from (((`tp2`.`productos` `p` join `tp2`.`detallepedidos` `d`
        on ((`p`.`ID` = `d`.`ProductoID`))) join `tp2`.`productoscategorias` `pc`
       on ((`p`.`ID` = `pc`.`ProductoID`))) join `tp2`.`categorias` `c` on ((`c`.`ID` = `pc`.`CategoriaID`)))
group by `p`.`ID`, `Nombre_Producto`, `c`.`NombreCategoria`
order by `Cantidad_Vendida` desc
limit 10;

