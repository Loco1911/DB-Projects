create
    definer = renzo@`%` procedure stock_producto(IN id_producto int)
begin
    declare
        producto_existe int;

    select count(*) into producto_existe
    from productos
    where id = id_producto;

    if producto_existe = 0 then
        signal sqlstate '45000'
            set message_text = 'Error: El producto especificado no existe.';
        else
            select NombreProducto, Stock from productos p where ID = id_producto;
    end if;
end;

