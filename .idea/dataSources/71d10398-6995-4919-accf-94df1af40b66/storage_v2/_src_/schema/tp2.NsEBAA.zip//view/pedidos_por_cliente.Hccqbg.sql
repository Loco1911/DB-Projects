create definer = renzo@`%` view pedidos_por_cliente as
select `p`.`ClienteID` AS `ClienteID`, `c`.`Nombre` AS `Nombre`, count(`p`.`ID`) AS `Total_Pedidos`
from (`tp2`.`pedidos` `p` join `tp2`.`clientes` `c` on ((`c`.`ID` = `p`.`ClienteID`)))
group by `p`.`ClienteID`
order by `Total_Pedidos` desc;

