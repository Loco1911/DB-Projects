create
    definer = renzo@`%` procedure actualizar_stock_por_id(IN id_prod int, IN stock_nuevo int)
begin
    declare producto_existe int;

    select count(*) into producto_existe from productos where ID = id_prod;

    if producto_existe = 0 then
        signal sqlstate '45000'
            set message_text = 'Error: El producto especificado no existe.';
    else
        update productos set Stock = stock_nuevo where ID = id_prod;
    end if;
end;

