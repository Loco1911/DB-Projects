create
    definer = renzo@`%` procedure stock_por_id(IN id_prod int)
begin
    declare producto_existe int;

    select count(*) into producto_existe from productos where ID = id_prod;

    if producto_existe = 0 then
            signal sqlstate '45000'
            set message_text = 'Error: El producto especificado no existe.';

            else
        select NombreProducto, Stock from productos p where ID = id_prod;
    end if;
end;

